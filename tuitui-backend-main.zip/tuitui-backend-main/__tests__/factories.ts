// const faker = require('faker');
// const { factory } = require('factory-girl');
// const User = require('../src/app/models/user');
// const Fatura = require('../src/app/models/faturas');
// const mongoose = require('../src/database');

// factory.define('User', User, {
//   username: faker.internet.userName(),
//   password: faker.internet.password(),
// });

// factory.define('Fatura', Fatura, {
//   name: faker.finance.accountName(),
//   services: [
//     { name: faker.commerce.productName(), value: faker.commerce.price() }
//   ],
//   validade: faker.date.future(),
//   totalValue: faker.commerce.price(),
//   user: mongoose.Types.ObjectId(Date.now())
// });

// module.exports = factory;

// export {}
