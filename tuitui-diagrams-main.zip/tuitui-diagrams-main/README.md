# tuitui-diagrams

Diagramas do trabalho interdiciplinar do 7° semestre de Ciências da Computação da Universidade Católica de Santos

## Integrantes

- Artur Freire dos Santos
- Gabriel Gonçales Lopes
- Gabriel Teodoro Suzano
- Gustavo Medeiros Madeira 
- Lucas Silva dos Anjos
- Luis Gustavo Oliveira Machado
- Vinicius Pereira Freire Costa

## Diagramas


Diagrama do Caso de Uso:

![Imagem do Diagrama de Caso de Uso](https://github.com/lgrandiel/tuitui-diagrams/blob/main/dist/use-case-diagram.png)



Diagrama de Implantação:

![Imagem de Diagrama de Implantação](https://github.com/lgrandiel/tuitui-diagrams/blob/main/dist/implantation-diagram.png)


Diagrama de Componentes:

![Imagem de Diagrama de Componentes](https://github.com/lgrandiel/tuitui-diagrams/blob/main/dist/component-diagram.png)


