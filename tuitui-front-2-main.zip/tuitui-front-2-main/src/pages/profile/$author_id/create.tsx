export default function CreateArticlePage() {
  return (
    <div>
      <h1>CreateArticlePage</h1>
    </div>
  )
}

export async function loader() {
  return {}
}
