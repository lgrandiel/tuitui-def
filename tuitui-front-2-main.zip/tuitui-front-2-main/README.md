# TuiTui

[API do Projeto](https://github.com/freirart/tuitui-backend)

## Pré requisitos:

- [Node 18.x](https://nodejs.org/en/)
- [Eslint Plugin](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)

### Iniciando:

```sh
$ npm install
$ npm run dev
```
